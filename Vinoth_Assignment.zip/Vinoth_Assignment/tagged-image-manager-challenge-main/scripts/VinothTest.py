import requests
import os


def checkForTag(Tagname):
	for rec in listTags():
		if rec['name'].lower() == Tagname.lower():
			return True
	return False
	
def addTag(Tagname):
	try:
		if checkForTag(Tagname):
			return "Error: Duplicate of existing tag"
				
		url = "http://localhost:8000/v1/tags"
		headers = {"content-type": "application/json"}
		data = {
  			"name": Tagname
		}
		response = requests.post(url, headers=headers, json=data)
		if response.status_code==200:
			rData=response.json()
			return "Sucess: Tag has been added"
	except:
		pass
	return "Error: Unable to insert"

def listTags():
	try:
		url = "http://localhost:8000/v1/tags"
		headers = {"content-type": "application/json"}
		response = requests.get(url, headers=headers)
		if response.status_code==200:
			rData=response.json()
			return rData['results'] 
	except:
		pass
	return {"results":[]}
	
def printIDTags():
	nameTags=listTags()
	dataKeys={}
	for rec in nameTags:
		dataKeys[rec['id']]=rec['name']
	SortKeys=list(dataKeys.keys())
	SortKeys.sort()
	print("ID{}Tag".format(' '*9))
	for ks in SortKeys:
		print("{}{}".format(ks,' '*10)[:10],dataKeys[ks])


while True:
	os.system('clear')
	print("1. List all tags\n2. Add New Tag\n3. Check for existing tag\n4. Exit\n")
	print("Select ur option:")
	option= input()
	
	if option=='1':
		print("List all tags\n\n")
		printIDTags()
	elif option=='2':
		print("Enter the Tag name to be added:")
		Tagname= input()
		print(addTag(Tagname))
	elif option=='3':
		print("Enter the Tag name to be checked:")
		Tagname= input()
		if checkForTag(Tagname):
			print("Tag is present")
		else:
			print("Tag is not present")
	elif option=='4':
		break
	else:
		print("Please enter a valid option\n")
		
	print("\n\nEnter any key to continue")
	input()

