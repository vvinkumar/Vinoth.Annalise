from os import environ

from chalice.app import CognitoUserPoolAuthorizer

environ["COGNITO_POOL_ARN"] = "set-me"
cognito_authorizer = CognitoUserPoolAuthorizer(
    "CognitoAuthorizer",
    provider_arns=[environ["COGNITO_POOL_ARN"]],
)
